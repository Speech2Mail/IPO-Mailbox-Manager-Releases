﻿IPO Mailbox Manager

Run: IPO Mailbox Manager.exe
Requirement: Microsoft .NET 8 Windows Desktop Runtime x64 must be installed on the PC.
Website: https://Speech2Mail.ca
